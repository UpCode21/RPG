﻿using RPG.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RPG
{
    public class SistemaDeCombate : Personagens
    {
        public int Dano { get; protected set; }

        public SistemaDeCombate (int dano)
        {
            Dano = dano;
        }

        public int TiraVida()
        {
            if (Dano > 0)
            {
                Vida -= Dano;
            }
            return Vida();
        }

        public int Pancada()
        {
            Dano = 5;
            return Dano;
        } 

        public int RachaChao()
        {
            Dano = 15;
            return Dano;
        }

        public int BolaDeFogo()
        {
            Dano = 20;
            return Dano;
        }

        public int Vida()
        {
            throw new NotImplementedException();
        }
    }
}
