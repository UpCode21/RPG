﻿using RPG.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RPG
{
    interface IGerais
    {
        int Vida();
        int Dano();
    }
}
