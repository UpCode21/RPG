﻿using RPG.Classes;
using RPG.Inimigos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RPG
{
    class Program
    {
        static void Main(string[] args)
        {
            DarkKnight gisa = new DarkKnight( "Gisa", 100, 100 );

            Hunter ismael = new Hunter( "Ismael", 100, 100 );

            Mago yvens = new Mago("Yvens", 100, 100);

            Paladino joao = new Paladino("João", 100, 100);
        }

        public void Inimigos()
        {
            Urubu urubu = new Urubu( "Urubu", 100 );

            CatitaMutante catita = new CatitaMutante( "CatitaMutante", 150 );

            PeixeBolha peixe = new PeixeBolha( "PeixeBolha", 125 );

            Kraken kraken = new Kraken( "Kraken", 300 );
        }
    }
}
