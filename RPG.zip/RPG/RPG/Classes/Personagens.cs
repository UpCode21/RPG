﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RPG.Classes
{
    public class Personagens
    {
        public string Nome { get; set; }
        public int Vida { get; set; }
        public int Mana { get; set; }
        public int Dano { get; protected set; }

        public Personagens (string nome, int vida, int mana, int dano)
        {
            Nome = nome;
            Vida = vida;
            Mana = mana;
        }
        
    }
}
