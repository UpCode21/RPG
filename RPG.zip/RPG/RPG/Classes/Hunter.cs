﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RPG.Classes
{
    public class Hunter : Personagens
    {
        public Hunter(string nome, int vida, int mana) : base(nome, vida, mana)
        {
            Console.WriteLine("Personagem criado!!!");
        }
    }
}
