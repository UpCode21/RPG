﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RPG.Classes
{
    public class DarkKnight : Personagens
    {
        public DarkKnight (string nome, int vida, int mana, int dano) : base(nome, vida, mana, dano)
        {
            Console.WriteLine("Personagem criado!!!");
        }

        public int Pancada()
        {
            Dano = 20;
            return Dano;
        }


    }
}
