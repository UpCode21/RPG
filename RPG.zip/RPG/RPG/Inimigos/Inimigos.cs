﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RPG.Inimigos
{
    public class Inimigos
    {
        public string Nome { get; set; }
        public int Vida { get; set; }

        public Inimigos (string nome, int vida)
        {
            Nome = nome;
            Vida = vida;
        }
    }
}
