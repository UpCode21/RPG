﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RPG.Inimigos
{
    public class Urubu : Inimigos
    {
        public Urubu(string nome, int vida) : base(nome, 300)
        {
            Console.WriteLine("Inimigo Criado!!!");
        }
    }
}
